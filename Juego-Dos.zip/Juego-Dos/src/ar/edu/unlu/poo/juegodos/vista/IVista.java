package ar.edu.unlu.poo.juegodos.vista;

import ar.edu.unlu.poo.juegodos.controlador.*;
import ar.edu.unlu.poo.juegodos.modelo.*;

public interface IVista {
    void setControlador(Controlador controlador);
}

