package ar.edu.unlu.poo.juegodos.modelo;

public enum ColorCarta {
    ROJO, AMARILLO, VERDE, AZUL, MULTICOLOR
}
